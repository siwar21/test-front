export default interface User {
    checked:boolean
    name:String,
    phone:String,
    ssn:String,
    dob:Date,
    hired:Date,
    cdl:String,
    state:String,
    cdlExp:String,
    medicalExp:String,
    mvrExp:String
}