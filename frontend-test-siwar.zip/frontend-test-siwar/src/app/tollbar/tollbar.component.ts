import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tollbar',
  templateUrl: './tollbar.component.html',
  styleUrls: ['./tollbar.component.css']
})
export class TollbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
